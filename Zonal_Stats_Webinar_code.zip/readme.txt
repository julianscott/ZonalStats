Unzip to folder. Double click on .RProj file to open the R project in R Studio.
This sets the working directory automatically. 
Open the *.R file. 
Run the code line by line and read comments to learn more. 